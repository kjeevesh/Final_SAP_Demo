from utils.sap_itsm_utils import *

parser = Utilities()

# establish a connection to your SAP system
conn = pyrfc.Connection(
    ashost='10.31.101.161',
    sysnr='04',
    client='100',
    user='etd_alert',
    passwd='jan@1234'
)

# define the input parameter for the function module
it_date = ['20230205']

# Set the date range
date_from = '2023-02-01'
date_to = '2023-05-31'

# # Set additional options for the function call
# options = [{'TEXT': 'DATE_RANGE', 'VALUE': f'{date_from}..{date_to}'}]

# Set additional options for the function call
date_options = [{'TEXT': 'DATE_RANGE', 'LOW': date_from, 'HIGH': date_to}]

# SD_002

lt_bkpf = conn.call(
    'RFC_READ_TABLE',
    QUERY_TABLE='BKPF',
    DELIMITER='|',
    FIELDS=[{'FIELDNAME': 'BUKRS'}, {'FIELDNAME': 'BELNR'}, {'FIELDNAME': 'GJAHR'}, {'FIELDNAME': 'BLART'}, {'FIELDNAME': 'BLDAT'}, {'FIELDNAME': 'BUDAT'}, {'FIELDNAME': 'MONAT'}, {'FIELDNAME': 'USNAM'}, {'FIELDNAME': 'TCODE'}]
)['DATA']

lt_bkpf_1 = conn.call(
    'RFC_READ_TABLE',
    QUERY_TABLE='BKPF',
    DELIMITER='|',
    FIELDS=[{'FIELDNAME': 'BUKRS'}, {'FIELDNAME': 'BELNR'}, {'FIELDNAME': 'GJAHR'}, {'FIELDNAME': 'BLART'}, {'FIELDNAME': 'BLDAT'}, {'FIELDNAME': 'BUDAT'}, {'FIELDNAME': 'MONAT'}, {'FIELDNAME': 'USNAM'}, {'FIELDNAME': 'TCODE'}],
    OPTIONS=date_options
)['DATA']

print("Before date filtering > ",len(lt_bkpf))
print("After date filtering > ",len(lt_bkpf_1))

# lt_bseg = conn.call(
#     'RFC_READ_TABLE',
#     QUERY_TABLE='BSEG',
#     DELIMITER='|',
#     FIELDS=[{'FIELDNAME': 'KUNNR'}, {'FIELDNAME': 'BUKRS'}, {'FIELDNAME': 'BELNR'}, {'FIELDNAME': 'GJAHR'}]
# )['DATA']

# lt_bsad = conn.call(
#     'RFC_READ_TABLE',
#     QUERY_TABLE='BSAD',
#     DELIMITER='|',
#     FIELDS=[{'FIELDNAME': 'AUGBL'}, {'FIELDNAME': 'AUGGJ'}, {'FIELDNAME': 'AUGDT'}, {'FIELDNAME': 'KUNNR'}, {'FIELDNAME': 'BUKRS'}]
# )['DATA']

# parser.write_json_file("sd_002_bkpf.json", lt_bkpf)
# parser.write_json_file("sd_002_bseg.json", lt_bseg)
# parser.write_json_file("sd_002_bsad.json", lt_bsad)




# # Call rfc_read_table function
# result = conn.call('RFC_READ_TABLE', QUERY_TABLE='your_table_name', OPTIONS=options)

# # Process the result or access the data
# data = result['DATA']
# for row in data:
#     # Process each row of data
#     pass

# Close the connection
conn.close()