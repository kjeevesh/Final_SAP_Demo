sample = ['P']

if sample != []:
    print("It's not empty")

print("It's empty")