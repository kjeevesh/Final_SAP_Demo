from utils.sap_itsm_utils import *
from utils.text_to_json_util import *

class BussCtrl_001(object):
    # A class to host all business controls for the py_sap module.

    def __init__(self) -> None:
        self.utils = Utilities()
        
        creds_fileName = "config/sap_cred.json"
        self.rfc_creds = self.utils.read_json_file(creds_fileName)
    
    def srini_code(self):
        
        # erev = ["bstyp","edokn","fgdat","fgnam"]
        erev_fields = ['BSTYP', 'EDOKN', 'FGDAT', 'FGNAM']
        erev_options = []
        
        # ekko = ["ebeln","bukrs","bstyp","aedat","ernam","lifnr","ekorg","ekgrp","reswk","ktwrt","frggr","frgsx","frgke","loekz"]
        ekko_fields = ['EBELN', 'BUKRS', 'BSTYP', 'AEDAT', 'ERNAM', 'LIFNR', 'EKORG', 'EKGRP', 'RESWK', 'KTWRT', 'FRGGR', 'FRGSX', 'FRGKE', 'LOEKZ']
        ekko_options = []
        
        # lfa1 = ["lifnr","name1"]
        lfa1_fields = ['LIFNR', 'NAME1']
        lfa1_options = []
        
        # ekpo = ["ebeln","ebelp","werks","banfn","loekz"]
        ekpo_fields = ['EBELN', 'EBELP', 'WERKS', 'BANFN', 'LOEKZ']
        ekpo_options = []
        
        # ekkn = ["ebeln","ebelp","kostl","loekz"]
        ekkn_fields = ['EBELN', 'EBELP', 'KOSTL', 'LOEKZ']
        ekkn_options = []
        
        # get the data from SAP table        
        data_erev = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'EREV', erev_fields, erev_options)['DATA']        
        
        data_ekko = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'EKKO', ekko_fields, ekko_options)['DATA']        
        
        data_ekpo = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'EKPO', ekpo_fields, ekpo_options)['DATA']
        
        data_lfa1 = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'LFA1', lfa1_fields, lfa1_options)['DATA']        
        
        data_ekkn = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'EKKN', ekkn_fields, ekkn_options)['DATA']        
        
        
        
        # # set the file path
        # file_path1 = 'erev.json'
        # file_path2 = 'ekko.json'
        # file_path3 = 'ekpo.json'
        # file_path4 = 'lfa1.json'
        # file_path5 = 'ekkn.json'
        

        # # read the data into a string
        # with open(file_path1, 'r') as f1:
        #     data_erev = json.load(f1)
        # with open(file_path2, 'r') as f2:
        #     data_ekko = json.load(f2)
        # with open(file_path3, 'r') as f3:
        #     data_ekpo = json.load(f3)
        # with open(file_path4, 'r') as f3:
        #     data_lfa1 = json.load(f3)
        # with open(file_path5, 'r') as f3:
        #     data_ekkn = json.load(f3)
    
        # create a pandas DataFrame from the list of dictionaries
        for i in range(5):
            if i==0:
                erev=pd.json_normalize(data_erev)
                erev[["bstyp","edokn","fgdat","fgnam"]] = erev['WA'].str.split('|', expand=True)
                erev=erev.drop("WA",axis=1)
            elif i==1:
                ekko=pd.json_normalize(data_ekko)
                ekko[["ebeln","bukrs","bstyp","aedat","ernam","lifnr","ekorg","ekgrp","reswk","ktwrt","frggr","frgsx","frgke","loekz"]] = ekko['WA'].str.split('|', expand=True)
                ekko=ekko.drop("WA",axis=1)
            elif i==2:
                lfa1=pd.json_normalize(data_lfa1)
                lfa1[["lifnr","name1"]] = lfa1['WA'].str.split('|', expand=True)
                lfa1=lfa1.drop("WA",axis=1)
            elif i==3:
                ekpo=pd.json_normalize(data_ekpo)
                ekpo[["ebeln","ebelp","werks","banfn","loekz"]] = ekpo['WA'].str.split('|', expand=True)
                ekpo=ekpo.drop(["WA"],axis=1)
            else:
                ekkn=pd.json_normalize(data_ekkn)
                ekkn[["ebeln","ebelp","kostl","loekz"]] = ekkn['WA'].str.split('|', expand=True)
                ekkn=ekkn.drop(["WA"],axis=1)
        
        start_date = '2023-01-02'
        end_date = '2023-01-28'
        
        # Generate a range of dates 
        date_range = pd.date_range(start= start_date, end=end_date)
        # Convert the date range to the list
        it_date = date_range.strftime("%Y-%m-%d").tolist()

        result1= erev[(erev['fgdat'].isin(it_date)) & (erev['bstyp']== 'F')][['bstyp','edokn','fgdat']]
        result2 = ekko.loc[(ekko['ebeln'].isin(result1['edokn'])) &
                    (ekko['bstyp'] == 'F') &
                    ((ekko['frgke'] == 'R') | (ekko['frgke'] == 'N')) & (ekko['loekz']== '')]
        
        result2 = result2[['ebeln', 'bukrs', 'bstyp', 'aedat', 'ernam', 'lifnr', 'ekorg', 'ekgrp', 'reswk', 'ktwrt', 'frggr', 'frgsx', 'frgke']]
        result3 = erev.loc[erev['edokn'].isin(result2['ebeln'])]
        result3 = result3[['edokn','fgdat','fgnam']]
        result4 = ekpo.loc[(ekpo['ebeln'].isin(result2['ebeln'])) & (ekpo['loekz'] == " ")]
        result4 = result4[['ebeln','ebelp','werks','banfn']]
        result5 = lfa1.loc[lfa1['lifnr'].isin(result2['lifnr'])]
        result5 = result5[['lifnr','name1']]
        result6 = ekkn.loc[(ekkn['ebeln'].isin(result2['ebeln'])) & (ekkn['loekz']== '') ]
        result6 = result6[['ebeln','ebelp','kostl']]
        lt_output = []
        
        if len(result1)>0 and len(result2)>0:
            
            for _, ls_eban in result1.iterrows():
                for _, ls_ekko in result2.iterrows():
                        if (ls_eban.loc["ebeln"] == ls_ekko.loc["ebeln"]) & (ls_eban.loc["ernam"] == ls_ekko.loc["ernam"]):
                            ls_final = {
                            "aedat":   ls_ekko.loc["aedat"],
                            "ebeln":   ls_ekko.loc["ebeln"],
                            "ernam_m": ls_ekko.loc["ernam"],
                            "banfn":   ls_eban.loc["banfn"],
                            "bsart":   ls_eban.loc["bsart"],
                            "werks":   ls_eban.loc["werks"],
                            "lgort":   ls_eban.loc["lgort"],
                            "ernam":   ls_eban.loc["ernam"]
                            }
                
                            lt_output.append(ls_final)
        lt_output=pd.DataFrame(lt_output)
        #print(len(lt_output.head()))
        
        # lt_output=lt_output.sort_values(["ebeln","ernam_m"], ascending=True)
        # lt_output=lt_output.drop_duplicates(keep="first")
        #var1=lt_output.to_excel("lt_output.xlsx",index=False)
        print(len(lt_output))   
    
    def bus001_main(self):
        # A function to execute the business control for BUS001        
        # Step 1 : Get the purchase order list form EREV table for February month     
        l1_pur_ord = self.l1_create_purchase_order_list()
        
        # # Step 2 : Get the users list from EKKO table for the generated purchase order list
        l2_user_list = self.l2_create_uses_list(l1_pur_ord)
        
        # # Step 3 : Check if po creation and release is done by the same person
        # # FGNAM[EREV] == ERNAM[EKKO] 
        first_exception_list = self.l3_check_usernames(l1_pur_ord, l2_user_list)
        
        # Step 4 : Check for purchase requisition number
        # if EKPO-BANFN is blank
        second_exception_list = self.l4_check_requisition(l2_user_list)
        
        # # Step 5 : Check the DB to see if the generated po numbers have already been raised or not
        # final_exception_list = self.l5_po_comparison(second_exception_list)

        # # if not len(final_exception_list) == 0:
            
        # # Step 6 : Generate ITSM data for the final exception list
        # itsm_data = self.l6_generate_itsm_data(final_exception_list)
        
        # # Step 7 : Raise tickets for the exceptions found
        # self.l7_create_json_ticket_data()
        
        # #     # Step 8 : Update the database with the po numbers of raised exceptions
        #     #self.update_excel(final_exception_list, excel_name)       
        
        return
    
    def l1_create_purchase_order_list(self):

        # Step 1
        # Create the purchase order list
        # EDOKN is the primary key
        # Status : First level filtering is done.

        
        fields0 = ['EDOKN','FGDAT', 'FGNAM', 'BSTYP']
        options0 = [{'TEXT': "BSTYP = 'F'"}]

        # make the RFC call to get the purchase order
        # purchase_order_data = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'EREV', fields0, options0)['DATA']
        
        purchase_order_data = TextToJson("dummydata/bus001/l1_erev.json").text_to_json()['DATA']

        
        # create a date range for filtering
        date_range = []
        date_range = self.utils.date_range(2)        

        po_list = []
        i = 0
        table_length = len(purchase_order_data)
        
        # break down the raw data into nested lists for data processing
        for p_o in range(table_length):

            data_to_add = purchase_order_data[i]['WA']
            data_split = data_to_add.split("|")
            po_list.append(data_split)
            i = i + 1
        
        final_po = []
        j = 0
        
        # applying a filter where doc type should be 'F'
        for po in range(len(po_list)):

            data_to_filter = po_list[j]
            if data_to_filter[3] == 'F':
                final_po.append(data_to_filter)
                j = j + 1
            else:
                j = j + 1
                
        # second level of filtering to get data for one specific month        
        main_list = final_po
        given_list = date_range
        final_list = []
        
        for sublist in main_list:
            for value in given_list:
                if value in sublist:
                    final_list.append(sublist)
                    break
        
        # get the purchase order numbers for displaying
        k = 0
        data_to_extract = []
        
        for x in range(len(final_list)):            
            data_to_extract.append(final_list[k][0])
            k = k + 1
        
        print("----------01--> MC_SD_S002------------------------------------------------------")

        print("Total purchase order list extracted      >   ", len(final_po))
        print("Purchase order list after filtering      >   ", len(final_list))
        print(final_list)
        print("")        
        
        return final_list
    
    def l2_create_uses_list(self, l1_pur_order):
        
        # Level 2 filtering
        # Create the users list
        # EBELN is the primary key
        
        
        fields1 = [{'FIELDNAME': 'EBELN'}, {'FIELDNAME': 'BUKRS'}, {'FIELDNAME': 'BSTYP'}, {'FIELDNAME': 'AEDAT'}, {'FIELDNAME': 'ERNAM'}, {'FIELDNAME': 'LIFNR'}, {'FIELDNAME': 'EKORG'}, {'FIELDNAME': 'EKGRP'}, {'FIELDNAME': 'RESWK'}, {'FIELDNAME': 'KTWRT'}, {'FIELDNAME': 'FRGGR'}, {'FIELDNAME': 'FRGSX'}, {'FIELDNAME': 'FRGKE'}, {'FIELDNAME': 'LOEKZ'}]
        options1 = [{'TEXT': "BSTYP = 'F' AND FRGKE = 'R' AND LOEKZ = ''"}]

        # lt_ekko = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'EKKO', fields1,options1)['DATA']
        lt_ekko = TextToJson("dummydata/bus001/l2_ekko.json").text_to_json()
        
        po_list = []
        i = 0
        table_length = len(lt_ekko)
        
        # break down the raw data into nested lists for data processing
        for p_o in range(table_length):

            data_to_add = lt_ekko[i]['WA']
            data_split = data_to_add.split("|")
            po_list.append(data_split)
            i = i + 1
        
        # generate a list of pur_nos for filtering from level 1
        k = 0
        data_to_extract = []        
        for x in range(len(l1_pur_order)):
            
            data_to_extract.append(l1_pur_order[k][0])
            k = k + 1
        
        # filter the user's list from the level 1 purchase order list
        given_list = data_to_extract
        main_list = po_list
        
        final_list = []
        
        for sublist in main_list:
            for value in given_list:
                if value in sublist:
                    final_list.append(sublist)
                    break
        
        # get the purchase order numbers for displaying
        l = 0
        data_to_extract_2 = []
        
        for x in range(len(final_list)):            
            data_to_extract_2.append(final_list[l][0])
            l = l + 1
                 
        print("Total Users list extracted               >   ", len(po_list))        
        print("User list after filtering                >   ", len(final_list))
        print("")       
        
        return final_list
    
    def l3_check_usernames(self, po_list, user_list):
        
        # Level 3 filtering
        # Check if po creation and release is done by the same person
        # FGNAM[EREV] == ERNAM[EKKO]        
        
        # currently 3                
        erev_list = po_list
        
        # currently 2
        ekko_list = user_list
        
        exception_list = [] 
        
        for sublist in erev_list:
            for value in ekko_list:
                if value[4] == sublist[2]:
                    exception_list.append(value)
                    break
        
        # generate a list of pur_nos for displaying
        k = 0
        data_to_extract = []        
        for x in range(len(exception_list)):            
            data_to_extract.append(exception_list[k][0])
            k = k + 1
        
        print("Checking for exceptions where PO is created and release by the same person......")
        print("Total exceptions extracted               >   ", len(exception_list))             
        print("")
        
        return exception_list
    
    def l4_check_requisition(self, l1_pur_order):
        
        # Second exception
        # Check for purchase requisition number
        # if EKPO-BANFN is blank
        
        
        fields2 = [{'FIELDNAME': 'EBELN'}, {'FIELDNAME': 'BANFN'}]
        options2 = []
        
        # lt_ekpo = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'EKPO', fields2, options2)['DATA']
        lt_ekpo = TextToJson("dummydata/bus001/l4_ekpo.json").text_to_json()

        # break down the raw data into nested lists for data processing
        po_list = []
        i = 0
        table_length = len(lt_ekpo)
        
        for p_o in range(table_length):

            data_to_add = lt_ekpo[i]['WA']
            data_split = data_to_add.split("|")
            po_list.append(data_split)
            i = i + 1
        
        # generate a list of pur_nos for filtering from level 1
        k = 0
        data_to_extract = []
        
        for x in range(len(l1_pur_order)):            
            data_to_extract.append(l1_pur_order[k][0])
            k = k + 1
        
        # filter the user's list from the level 1 purchase order list
        given_list = data_to_extract
        main_list = po_list        
        final_list = []
        
        for sublist in main_list:
            for value in given_list:
                if value in sublist:
                    final_list.append(sublist)
                    break
        
        # filter the ones with BANFN as blank
        l4_final_list = []        
        for x in final_list:
            if x[1] == '':
                l4_final_list.append(x)
        
        # get the purchase order numbers for displaying
        l = 0
        data_to_extract_2 = []
        
        for x in range(len(l4_final_list)):            
            data_to_extract_2.append(l4_final_list[l][0])
            l = l + 1
        
        print("Checking for exceptions where Purchase requisition number is blank......")
        print("Total exceptions extracted               >   ", len(l4_final_list))      
        print(l4_final_list)       
        print("")
                
        return l4_final_list
    
    def l5_po_comparison(self, final_list):
        
        # A function to read the po values already updated and only execute the remaining        
        # generate the po's from the list        
       
        # A function to update the mysql table for comparison
        exception_list = []        
        i = 0
        
        # get the pur_no from the input list into a seperate list        
        for x in final_list:
            exception_list.append(x[i])
        
        # excel_name = 'datastore/DB_temp.xlsx'
            
        # read the database to get the list of exceptions that has already been found        
        # db_list = self.utils.read_excel_sheet(excel_name, 'Sheet', 'A')     
        
        # find which elements from exception list are not in db list
        # final_exception_list = []
        # for p_o in exception_list:
        #     if p_o not in db_list:
        #         final_exception_list.append(p_o)
        
        print("Step 5 :")
        print("Checking if the exceptions raised have recorded in DB or not ......")
        print(exception_list)
        
        # if len(final_exception_list) == 0:
        #     print("Exceptions found have already been notified and updated in the Database.")
            
        # else:
        #     print("Exceptions found have not been notified to Jira yet.")       

        return exception_list
    
    def update_excel(self, final_list, excel_name):
        
        
        # A function to update the mysql table for comparison
        excel_time_list = datetime.datetime.now().strftime('%H:%M:%S')
        
        # load the workbook
        #print(excel_name)
        workbook = openpyxl.load_workbook(excel_name)

        # select the worksheet
        worksheet = workbook.active
        
        # read the database to get the list of exceptions that has already been found        
        existing_list = self.utils.read_excel_sheet(excel_name, 'Sheet', 'A')
        
        final_list = existing_list + final_list
        
        # using list comprehension to
        # perform removal of empty values
        final_list = [i for i in final_list if i]
        
        # Write each value to a new row in the first column
        for value in final_list:
            cell = worksheet.cell(row=final_list.index(value)+2, column=1)
            cell.value = value
            cell_2 = worksheet.cell(row=final_list.index(value)+2, column=2)
            cell_2.value = str(excel_time_list)

        # save the workbook
        workbook.save(excel_name)
        workbook.close
    
    def l6_generate_itsm_data(self, final_exception_list):
        # A function to find the relevant data for the ITSM for the above exception list
        
        
        fields3 = [{'FIELDNAME': 'EBELN'}, {'FIELDNAME': 'BUKRS'}, {'FIELDNAME': 'AEDAT'}, {'FIELDNAME': 'ERNAM'}, {'FIELDNAME': 'LIFNR'}, {'FIELDNAME': 'KTWRT'}, {'FIELDNAME': 'RESWK'}, {'FIELDNAME': 'EKORG'}, {'FIELDNAME': 'EKGRP'}, {'FIELDNAME': 'FRGGR'}, {'FIELDNAME': 'FRGSX'}, {'FIELDNAME': 'FRGKE'}]
        fields3_options = []
        # lt_ekko = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'EKKO', fields3, fields3_options)['DATA']
        lt_ekko = TextToJson("dummydata/bus001/l6_ekko.json").text_to_json()

        
        fields4 = [{'FIELDNAME': 'EDOKN'}, {'FIELDNAME': 'FGNAM'}, {'FIELDNAME': 'FGDAT'}]
        fields4_options = []

        # lt_erev = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'EREV', fields4, fields4_options)['DATA']
        lt_erev = TextToJson("dummydata/bus001/l6_erev.json").text_to_json()
             
        
        fields5 = [{'FIELDNAME': 'EBELN'}, {'FIELDNAME': 'BANFN'}, {'FIELDNAME': 'WERKS'}]
        fields5_options = []

        # lt_ekpo = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'EKPO', fields5, fields5_options)['DATA']
        lt_ekpo = TextToJson("dummydata/bus001/l6_ekpo.json").text_to_json()
        
        ekko_list = self.utils.convert_wa_to_list(lt_ekko)
        erev_list = self.utils.convert_wa_to_list(lt_erev)
        ekpo_list = self.utils.convert_wa_to_list(lt_ekpo)
        
        final_ekpo_list = []
        final_ekko_list = []
        final_erev_list = []
        
        for value in final_exception_list:
            for sublist in ekpo_list:
                if value in sublist:
                    final_ekpo_list.append(sublist)
                    break
        for value in final_exception_list:
            for sublist in ekko_list:
                if value in sublist:
                    final_ekko_list.append(sublist)
                    break
        for value in final_exception_list:
            for sublist in erev_list:
                if value in sublist:
                    final_erev_list.append(sublist)
                    break
        
        final_nested_list = final_ekko_list + final_ekpo_list + final_erev_list
        
        itsm_list = []
        individual_list = []
        
        for value in final_exception_list:
            individual_list = [lst for lst in final_nested_list if lst[0] == value]
            combined_list = []
            for sublist in individual_list:
                combined_list.extend(sublist)
            itsm_list.append(combined_list)
            
        final_itsm_list = []
        
        for value in itsm_list:
            value.pop(12)
            value.pop(14)
            final_itsm_list.append(value)
            
        return final_itsm_list
    
    def l7_create_json_ticket_data(self):
        
        # A function to creata json tickets and send it to itsm        
        output_list = []        
        print("Creating JSON ticket - bus001")
        
        json_skeleton = self.utils.read_json_file('config/bus001/bus001_schema.json')            
            
        json_skeleton['MANDT'] = '1001'
        json_skeleton['RFC'] = '100'
        json_skeleton['REQ_NO'] = '1000000094'
        json_skeleton['ALERT_SEND_DATE'] = self.utils.current_date()
        json_skeleton['ALERT_SEND_TIME'] = '12:05:2023'
        json_skeleton['EVENT_ID'] = 'BUS333'
        json_skeleton['EVENT_DESCRIPTION'] = 'To highlight PO creation and approval done by the same user'
        json_skeleton['PROGRAM_NAME'] = 'ZBUS001'
        json_skeleton['SEVERITY'] = 'HIGH'
        json_skeleton['RISK_DESCRIPTION'] = 'Asset accessed irregularly by user'
        json_skeleton['EVENT_CLASS'] = 'BUSINESS'
        json_skeleton['CATEGORIES'] = 'SOD VIOLATIONS'
        json_skeleton['RISK_OWNER'] = 'ETD_ALERT'
        json_skeleton['ALERT_CLOSED_DATE'] = '1002'
        json_skeleton['ALERT_STATUS'] = 'SUCCESS'
        json_skeleton['STATUS'] = 'OPEN'
        json_skeleton['INCIDENT_NO'] = ''
                      
        output_list.append(json_skeleton)
        
        # sending the data to the Server
        self.utils.send_requests(output_list)
        
        return