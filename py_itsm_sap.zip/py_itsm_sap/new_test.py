# from pyrfc import Connection

# # Establish connection
# conn = Connection(user='etd_alert', passwd='jan@1234', ashost='10.31.101.161', sysnr='04', client='100')

# # Set the date range
# date_from = '2023-01-01'
# date_to = '2023-05-31'

# # Set additional options for the function call
# # options = [{'TEXT': 'BLART', 'LOW': date_from, 'HIGH': date_to}]

# options = [{'TEXT': "GJAHR = '2023'"}]

# # Set additional options for the function call
# # options = [
# #     {'SIGN': 'I', 'OPTION': 'BT', 'LOW': date_from, 'HIGH': date_to},
# # ]

# FIELDS_1=[{'FIELDNAME': 'BUKRS'}, {'FIELDNAME': 'MONAT'}, {'FIELDNAME': 'BELNR'}, {'FIELDNAME': 'GJAHR'}, {'FIELDNAME': 'BLART'}, {'FIELDNAME': 'BLDAT'}, {'FIELDNAME': 'BUDAT'}]

# # Call rfc_read_table function
# result = conn.call('RFC_READ_TABLE', QUERY_TABLE='BKPF',DELIMITER='|', FIELDS=FIELDS_1,OPTIONS=options)['DATA']

# print(len(result))
# # print(result)

# print(len(result_2))

# # # Process the result or access the data
# # data = result['DATA']
# # for row in data:
# #     # Process each row of data
# #     pass

# # Close the connection
# conn.close()


import pandas as pd
import ast
from datetime import datetime 
from utils.text_to_json_util import *
from utils.sap_itsm_utils import *

class ITSEC001(object):

    def __init__(self) -> None:
        
        self.utils = Utilities()
        
        creds_fileName = "config/sap_cred.json"
        self.rfc_creds = self.utils.read_json_file(creds_fileName)
        
        self.profile_names = ["SAP_ALL","SAP_NEW","S_A.SYSTEM","S_A.ADMIN","S_A.CUSTOMIZ","S_A.DEVELOP","S_A.USER","S_USER.ALL","S_ABAP_ALL","S_RZL_ADMIN"]
    
    def itsecExecute(self):
        
        l1 = self.l1_date_filtering()
        
        # if len(l1) != 0 :
            
        #     self.l2_create_json_ticket()
        
        
    def l1_date_filtering(self):
        
        # Get the current date and time in YYYYMMDD format
        today = datetime.now()
        
        # ["bname","usty","gltgy","gltgb"]        
        usr02_fields = ['BNAME', 'USTYP', 'GLTGV', 'GLTGB']
        usr02_options = []
        
        s_date = '20230516'
         # Construct the WHERE condition to filter data within the date range
        # where_condition = f"GLTGV" <= today AND "GLTGB" >= today "
        options1 = [{'TEXT': "BSTYP = 'F' AND FRGKE = 'R' AND LOEKZ = ''"}]
        where_c = "GLTGV <= '20230516' AND GLTGB >= '20230516'"
        where_c_2 = "GLTGV <= '" + s_date + "' AND GTLGB > = '" + s_date + "'"

        # Add the WHERE condition to the options
        options = [{'TEXT': where_c}]
        # ["bname","profile"]
        ust04_fields = ['BNAME', 'PROFILE']
        ust04_options = []
        # [["bname","fullname"]]
        user_addr_fields = ['BNAME', 'NAME_TEXTC']
        user_addr_options = []
        
        usr02_data = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'USR02', usr02_fields, options)['DATA']
        print(usr02_data)
        usr02_list = self.utils.convert_wa_to_list(usr02_data)
        # usr02_data = TextToJson("dummydata/itsec001/usr02.json").text_to_json()
        
        ust04_data = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'UST04', ust04_fields, ust04_options)['DATA']
        ust04_list = self.utils.convert_wa_to_list(ust04_data)
        # ust04_data = TextToJson("dummydata/itsec001/ust04.json").text_to_json()
        
        user_addr_data = self.utils.get_rfc_read_table_for_fields(self.rfc_creds, 'USER_ADDR', user_addr_fields, user_addr_options)['DATA']
        user_addr_list = self.utils.convert_wa_to_list(user_addr_data)
        # user_addr_data = TextToJson("dummydata/itsec001/user_addr.json").text_to_json()
        
        # First filtering - filter lists from ust04 for data relevant to our profiles list
        profile_names = self.profile_names
        
        filtered_profiles_perName = []
        
        for sublist in ust04_list:
            for value in profile_names:
                if value in sublist:
                    filtered_profiles_perName.append(sublist)
                    break
        
        # Second filtering - filter lists from ust02 for data based on today's date                
        filtered_profiles_perDate = []
        
        for lst in usr02_list:
            if lst[2] != '00000000' and lst[3] != '00000000':
                start_date = datetime.strptime(lst[2], '%Y%m%d')
                end_date = datetime.strptime(lst[3], '%Y%m%d')
                if start_date <= today <= end_date:
                    filtered_profiles_perDate.append(lst)
                    
        # remove duplicates from the list - Checking
        unique_list = []
        for sublist in filtered_profiles_perDate:
            if sublist not in unique_list:
                unique_list.append(sublist)
        
        # Third filtering - Merging usr02 and ust04 baased on 'bname' parameter
        filtered_perBname = []
        
        for lst1 in filtered_profiles_perName:
            for lst2 in filtered_profiles_perDate:
                if lst1[0].strip() == lst2[0].strip():
                    filtered_perBname.append(lst1 + lst2[1:])
                    break
        
        final_list = []
        
        for lst1 in filtered_perBname:
            if lst1[2] == 'A':
                final_list.append(lst1)
        
        # filtering based on bname from user_addr table
        # Third filtering - Merging usr02 and ust04 baased on 'bname' parameter
        filtered_perBname_1 = []
        
        for lst1 in final_list:
            for lst2 in user_addr_list:
                if lst1[0].strip() == lst2[0].strip():
                    filtered_perBname_1.append(lst1 + lst2[1:])
                    break
        
        print("UST04 Before filtering > ", len(ust04_data)) # 24347
        print("UST04 After filtering > ", len(filtered_profiles_perName)) # 1467
        
        print("USR02 Before filtering > ", len(usr02_list)) # 1011
        print("USR02 After filtering > ", len(unique_list)) # 23
            
        print("Filtered based on BNAME > ", len(filtered_perBname)) # 24
        print("Filtered by BSTYP = A > ", len(final_list)) # 20
        
        print("Final Bname filtered list length is > ",len(filtered_perBname_1)) # 20
        
        return filtered_perBname_1
    
    def l2_create_json_ticket(self):
        
        # A module to send json tickets to ITSM and EKS    
        output_list = []        
        srini_url = 'http://20.204.172.217:7777/Ticket/API/Create_Ticket'        
        
        # for value in data_list:
        json_skeleton = self.utils.read_json_file('config/itsec001/itsec001_schema.json')            
        json_skeleton['MANDT'] = '1002'
        json_skeleton['RFC'] = '100'
        json_skeleton['REQ_NO'] = '1000000095'
        json_skeleton['ALERT_SEND_DATE'] = self.utils.current_date()
        json_skeleton['ALERT_SEND_TIME'] = '12:05:2023'
        json_skeleton['EVENT_ID'] = 'IT_SEC_001'
        json_skeleton['EVENT_DESCRIPTION'] = 'To monitor the list of privileged users.'
        json_skeleton['PROGRAM_NAME'] = 'ZITSEC001'
        json_skeleton['SEVERITY'] = 'CRITICAL'
        json_skeleton['RISK_DESCRIPTION'] = 'Privilege escalation'
        json_skeleton['EVENT_CLASS'] = 'SECURITY'
        json_skeleton['CATEGORIES'] = 'SOD VIOLATIONS'
        json_skeleton['RISK_OWNER'] = 'ETD_ALERT'
        json_skeleton['ALERT_CLOSED_DATE'] = ''
        json_skeleton['ALERT_STATUS'] = 'SUCCESS'
        json_skeleton['STATUS'] = 'OPEN'
        json_skeleton['INCIDENT_NO'] = '' 
                 
        output_list.append(json_skeleton)            
        
        headers = {'Content-Type': 'application/json'}
        url = 'http://20.204.135.69:7777/Ticket/API/Create_Ticket'
        
        r = requests.post(url , headers=headers , json = output_list)
        print(f"Status Code: {r.status_code}, Response: {r.json()}") 
        
        return


controls = ITSEC001()

controls.itsecExecute()