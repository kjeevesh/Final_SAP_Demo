from utils.sap_itsm_utils import *
from controls.bus001 import *
from controls.itsec001 import *
from controls.mc_mm_p003 import *
from controls.mc_mm_p006 import *
from controls.mc_sd_s002 import *
from sched_mod.Schedule import *
import time


def monPrint(inData1, indata2, start):

    print(int(time.time() - start), inData1, "   ", indata2)


if __name__ == '__main__':

    sapcontrols_sched = set()
    timenowvar = time.time()

    control1 = BussCtrl_001()
    control2 = ITSEC001()
    control3 = MC_MM_P003()
    control4 = MC_MM_P006()
    control5 = MC_SD_S002()

    # sapcontrols_sched.add(SapControl(control1.bus001_main))
    # sapcontrols_sched.add(SapControl(control2.itsecExecute))
    sapcontrols_sched.add(SapControl(control3.p003Execute))
    sapcontrols_sched.add(SapControl(control4.p006Execute))
    sapcontrols_sched.add(SapControl(control5.s002Execute))
    
    #sapcontrols_sched.add(SapControl(monPrint, 'b','bbbb', start=timenowvar))
    #sapcontrols_sched.add(SapControl(monPrint, 'a','aaaa', start=timenowvar))

    abc = Schedule(time.time(), 10, sapcontrols_sched)
    abc.run()


